'''Illustrate braces in a formatted string.'''

a = 5
b = 9
setStr = 'The set is {{{}, {}}}.'.format(a, b)
print(setStr)
